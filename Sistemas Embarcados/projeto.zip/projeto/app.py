import time
import logging
import threading
from dataclasses import dataclass

import serial
from flask import Flask, render_template
from flask_socketio import SocketIO

# =========================================================
# CONFIGURAÇÕES
# =========================================================
SERIAL_PORT = "COM3"
BAUD_RATE = 9600
UPDATE_INTERVAL = 0.05

# =========================================================
# LOGGING
# =========================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(threadName)s | %(message)s"
)
logger = logging.getLogger("RADAR")

# =========================================================
# FLASK E SOCKET.IO (Corrigido para não conflitar com a Serial)
# =========================================================
app = Flask(__name__)
app.config["SECRET_KEY"] = "ultra-secure-radar"

# A mágica que faltava: forçar o threading clássico
socketio = SocketIO(
    app,
    cors_allowed_origins="*",
    async_mode="threading" 
)

# =========================================================
# DADOS
# =========================================================
@dataclass
class RadarData:
    distance: int = 0
    status: str = "SAFE"

# =========================================================
# RADAR (Lendo do Arduino)
# =========================================================
class ArduinoRadar:
    def __init__(self, port, baudrate):
        self.port_name = port
        self.baudrate = baudrate
        self.serial_port = None
        self.running = False
        self.data = RadarData()
        self.lock = threading.Lock()

    def connect(self):
        while True:
            try:
                logger.info(f"Conectando em {self.port_name}...")
                self.serial_port = serial.Serial(
                    self.port_name,
                    self.baudrate,
                    timeout=1
                )
                logger.info("Arduino conectado.")
                return
            except serial.SerialException as e:
                logger.error(f"Erro serial: {e}")
                logger.info("Tentando novamente em 3 segundos...")
                time.sleep(3)

    def parse_distance(self, raw_line):
        digits = "".join(filter(str.isdigit, raw_line))
        if not digits:
            return None
        return int(digits)

    def classify_distance(self, value):
        if value < 20:
            return "DANGER"
        elif value < 50:
            return "WARNING"
        return "SAFE"

    def read_loop(self):
        self.running = True
        self.connect()

        while self.running:
            try:
                if self.serial_port.in_waiting > 0:
                    raw = (
                        self.serial_port
                        .readline()
                        .decode("utf-8", errors="ignore")
                        .strip()
                    )
                    value = self.parse_distance(raw)

                    if value is not None:
                        status = self.classify_distance(value)
                        
                        with self.lock:
                            self.data.distance = value
                            self.data.status = status

                        logger.info(f"Distância={value} cm | Status={status}")

                        # Envia os dados para o Front-end
                        socketio.emit(
                            "sensor_update",
                            {
                                "distance": value,
                                "status": status
                            }
                        )
                time.sleep(UPDATE_INTERVAL)

            except serial.SerialException:
                logger.warning("Conexão perdida.")
                self.connect()
            except Exception as e:
                logger.exception(f"Erro inesperado: {e}")

    def start(self):
        thread = threading.Thread(
            target=self.read_loop,
            daemon=True,
            name="RadarThread"
        )
        thread.start()

# =========================================================
# INICIALIZAÇÃO E ROTAS
# =========================================================
radar = ArduinoRadar(SERIAL_PORT, BAUD_RATE)
radar.start()

@app.route("/")
def index():
    return render_template("index.html")

# =========================================================
# MAIN
# =========================================================
if __name__ == "__main__":
    logger.info("Servidor iniciado.")
    # use_reloader=False evita que o processo se duplique e trave a porta COM3
    socketio.run(
        app,
        host="0.0.0.0",
        port=5000,
        debug=True,
        use_reloader=False 
    )