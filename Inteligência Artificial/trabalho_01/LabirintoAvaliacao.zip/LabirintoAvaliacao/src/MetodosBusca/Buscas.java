package MetodosBusca;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import javax.swing.JOptionPane;

public class Buscas {
    
    private static final int[] dx = {0, 0, 1, -1};
    private static final int[] dy = {1, -1, 0, 0};
    
    public static boolean buscaAmplitude(int[][] labirinto, int startX, int startY, int goalX, int goalY) {
        int n = labirinto.length;
        Queue<Celula> fronteira = new LinkedList<>();
        boolean[][] visitado = new boolean[n][n];
        
        fronteira.add(new Celula(startX, startY, 0));
        
        while (!fronteira.isEmpty()) {
            Celula atual = fronteira.poll();
            int x = atual.x;
            int y = atual.y;
            
            if (x == goalX && y == goalY) {
                JOptionPane.showMessageDialog(null, "Saída encontrada (BFS)");
                return true;
            }
            
            visitado[x][y] = true;
            
            for (int i = 0; i < 4; i++) {
                int novoX = x + dx[i];
                int novoY = y + dy[i];
                
                if (ehValido(novoX, novoY, n, labirinto, visitado)) {
                    fronteira.add(new Celula(novoX, novoY, 0));
                    visitado[novoX][novoY] = true;
                }
            }
        }
        
        JOptionPane.showMessageDialog(null, "Nenhuma saída encontrada (BFS)");
        return false;
    }
    
    public static boolean buscaProfundidade(int[][] labirinto, int startX, int startY, int goalX, int goalY) {
        int n = labirinto.length;
        LinkedList<Celula> fronteira = new LinkedList<>();
        boolean[][] visitado = new boolean[n][n];
        
        fronteira.push(new Celula(startX, startY, 0));
        
        while (!fronteira.isEmpty()) {
            Celula atual = fronteira.pop();
            int x = atual.x;
            int y = atual.y;
            
            if (x == goalX && y == goalY) {
                JOptionPane.showMessageDialog(null, "Saída encontrada (DFS)");
                return true;
            }
            
            visitado[x][y] = true;
            
            for (int i = 0; i < 4; i++) {
                int novoX = x + dx[i];
                int novoY = y + dy[i];
                
                if (ehValido(novoX, novoY, n, labirinto, visitado)) {
                    fronteira.push(new Celula(novoX, novoY, 0));
                    visitado[novoX][novoY] = true;
                }
            }
        }
        
        JOptionPane.showMessageDialog(null, "Nenhuma saída encontrada (DFS)");
        return false;
    }
    
    public static boolean subidaDeEncosta(int[][] labirinto, int startX, int startY, int goalX, int goalY) {
        int n = labirinto.length;
        boolean[][] visitado = new boolean[n][n];
        Celula atual = new Celula(startX, startY, heuristica(startX, startY, goalX, goalY));
        
        while (true) {
            visitado[atual.x][atual.y] = true;
            
            if (atual.x == goalX && atual.y == goalY) {
                JOptionPane.showMessageDialog(null, "Saída encontrada (Hill Climbing)");
                return true;
            }
            
            Celula melhorVizinho = null;
            for (int i = 0; i < 4; i++) {
                int novoX = atual.x + dx[i];
                int novoY = atual.y + dy[i];
                
                if (ehValido(novoX, novoY, n, labirinto, visitado)) {
                    Celula vizinho = new Celula(novoX, novoY, heuristica(novoX, novoY, goalX, goalY));
                    if (melhorVizinho == null || vizinho.heuristica < melhorVizinho.heuristica) {
                        melhorVizinho = vizinho;
                    }
                }
            }
            
            if (melhorVizinho == null || melhorVizinho.heuristica >= atual.heuristica) {
                JOptionPane.showMessageDialog(null, "Nenhuma saída encontrada (Hill Climbing)");
                return false;
            }
            
            atual = melhorVizinho;
        }
    }
    
        public static boolean buscaAEstrela(int[][] labirinto, int startX, int startY, int goalX, int goalY) {
        int n = labirinto.length;
        PriorityQueue<Celula> fronteira = new PriorityQueue<>(Comparator.comparingInt(a -> a.heuristica));
        boolean[][] visitado = new boolean[n][n];
        
        fronteira.add(new Celula(startX, startY, heuristica(startX, startY, goalX, goalY)));
        
        while (!fronteira.isEmpty()) {
            Celula atual = fronteira.poll();
            int x = atual.x;
            int y = atual.y;
            
            if (x == goalX && y == goalY) {
                JOptionPane.showMessageDialog(null, "Saída encontrada (A*)");
                return true;
            }
            
            visitado[x][y] = true;
            
            for (int i = 0; i < 4; i++) {
                int novoX = x + dx[i];
                int novoY = y + dy[i];
                
                if (ehValido(novoX, novoY, n, labirinto, visitado)) {
                    int custo = heuristica(novoX, novoY, goalX, goalY);
                    fronteira.add(new Celula(novoX, novoY, custo));
                }
            }
        }
        
        JOptionPane.showMessageDialog(null, "Nenhuma saída encontrada (A*)");
        return false;
    }
    
    private static int heuristica(int x, int y, int goalX, int goalY) {
        return Math.abs(x - goalX) + Math.abs(y - goalY);
    }
    
    private static boolean ehValido(int x, int y, int n, int[][] labirinto, boolean[][] visitado) {
        return (x >= 0 && x < n && y >= 0 && y < n && labirinto[x][y] != 1 && !visitado[x][y]);
    }
}
