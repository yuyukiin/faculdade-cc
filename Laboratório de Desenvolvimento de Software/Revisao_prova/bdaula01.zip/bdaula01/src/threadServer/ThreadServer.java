/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package threadServer;

/**
 *
 * @author laboratorio
 */
import beans.Pessoa;
import dao.PessoaDAO;
import java.io.*;
import java.net.Socket;

public class ThreadServer extends Thread {
    private Socket clienteSocket;

    public ThreadServer(Socket clienteSocket) {  // Construtor não pode ser privado se queremos instanciar objetos externamente
        this.clienteSocket = clienteSocket;
    }

    @Override
    public void run() {
        try {
            ObjectOutputStream out = new ObjectOutputStream(clienteSocket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(clienteSocket.getInputStream());

            int id = in.readInt();
            System.out.println("ID recebido: " + id);

            // Simule a obtenção de uma Pessoa a partir do ID
            PessoaDAO pdao = new PessoaDAO();
            Pessoa p = pdao.getPessoa(id);

            out.writeObject(p);
            out.flush();

            // Fechamento adequado dos fluxos
            in.close();
            out.close();
            clienteSocket.close();
        } catch (IOException ex) {
            System.out.println("Erro ao lidar com o cliente");
            ex.printStackTrace();
        }
    }
}
