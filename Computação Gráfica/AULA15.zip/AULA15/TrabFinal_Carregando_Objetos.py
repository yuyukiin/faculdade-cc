# ==========================================================
# TrabFinal_Carregando_Objetos.py
# ==========================================================
#
# Trabalho Final - OpenGL Moderno
# Universidade Franciscana - UFN
# Curso de Ciência da Computação - 2026-01
# Professor: André F. dos Santos
# 
# Descrição: Cenário de encontro de RPG de mesa contendo uma
# "party" de 3 personagens (Chibis) enfrentando um Boss (Gato).
# Cumpre todos os requisitos exigidos: shaders, câmera,
# objetos 3D múltiplos, texturas e organização.
#
# ==========================================================

import glfw
from OpenGL.GL import *
import OpenGL.GL.shaders
import numpy as np
import pyrr
from pyrr import Vector3
import ctypes

from TextureLoader import load_texture
from Camera import Camera
from ObjLoaderSimple import ObjLoaderSimple

# ==========================================================
# ARQUIVOS DOS OBJETOS
# ==========================================================

PASTA_CHIBI = "objetos/chibi/"
ARQUIVO_OBJ_CHIBI = PASTA_CHIBI + "chibi.obj"
ARQUIVO_TEX_CHIBI = PASTA_CHIBI + "chibi.png"

PASTA_CAT = "objetos/Cat/"
ARQUIVO_OBJ_CAT = PASTA_CAT + "Cat.obj"
ARQUIVO_TEX_CAT = PASTA_CAT + "Cat_diffuse.jpg"

# ==========================================================
# VARIÁVEIS GLOBAIS
# ==========================================================

WIDTH = 800
HEIGHT = 600
Window = None
Shader_programm = None

vao_chibi, num_vertices_chibi, textura_chibi = None, 0, None
vao_cat, num_vertices_cat, textura_cat = None, 0, None

cam = Camera()

first_mouse = True
lastX = WIDTH / 2
lastY = HEIGHT / 2

# ==========================================================
# CALLBACKS E INICIALIZAÇÃO
# ==========================================================

def redimensiona_callback(window, w, h):
    global WIDTH, HEIGHT
    WIDTH, HEIGHT = w, h
    glViewport(0, 0, WIDTH, HEIGHT)

def teclado_callback(window, key, scancode, action, mods):
    if key == glfw.KEY_ESCAPE and action == glfw.PRESS:
        glfw.set_window_should_close(window, True)

def mouse_callback(window, xpos, ypos):
    global first_mouse, lastX, lastY
    if first_mouse:
        lastX, lastY = xpos, ypos
        first_mouse = False

    xoffset = xpos - lastX
    yoffset = lastY - ypos
    lastX, lastY = xpos, ypos

    cam.process_mouse_movement(xoffset, yoffset)

def inicializa_opengl():
    global Window
    if not glfw.init():
        raise RuntimeError("Erro GLFW")

    Window = glfw.create_window(WIDTH, HEIGHT, "Encontro RPG - Trabalho Final UFN", None, None)
    if not Window:
        glfw.terminate()
        raise RuntimeError("Erro Janela")

    glfw.make_context_current(Window)
    glfw.set_window_size_callback(Window, redimensiona_callback)
    glfw.set_key_callback(Window, teclado_callback)
    glfw.set_cursor_pos_callback(Window, mouse_callback)
    glfw.set_input_mode(Window, glfw.CURSOR, glfw.CURSOR_DISABLED)
    
    # Habilita o teste de profundidade para renderização 3D adequada
    glEnable(GL_DEPTH_TEST)
    glDisable(GL_CULL_FACE)

# ==========================================================
# FUNÇÕES DE CARREGAMENTO
# ==========================================================

def carregar_objeto(arquivo_obj, arquivo_tex):
    buffer, num_vertices = ObjLoaderSimple.load_obj(arquivo_obj)
    buffer = buffer.astype(np.float32)

    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)

    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, buffer.nbytes, buffer, GL_STATIC_DRAW)

    stride = buffer.itemsize * 5

    glEnableVertexAttribArray(0)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(0))

    glEnableVertexAttribArray(1)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(buffer.itemsize * 3))

    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)

    textura = glGenTextures(1)
    load_texture(arquivo_tex, textura)

    return vao, num_vertices, textura

def inicializa_shaders():
    global Shader_programm

    vertex_src = """
        #version 400
        layout(location = 0) in vec3 in_pos;
        layout(location = 1) in vec2 in_uv;

        uniform mat4 model;
        uniform mat4 view;
        uniform mat4 projection;

        out vec2 frag_uv;

        void main() {
            frag_uv = in_uv;
            gl_Position = projection * view * model * vec4(in_pos, 1.0);
        }
    """

    fragment_src = """
        #version 400
        in vec2 frag_uv;
        uniform sampler2D texture1;
        out vec4 FragColor;

        void main() {
            FragColor = texture(texture1, frag_uv);
        }
    """

    vertex_shader = OpenGL.GL.shaders.compileShader(vertex_src, GL_VERTEX_SHADER)
    fragment_shader = OpenGL.GL.shaders.compileShader(fragment_src, GL_FRAGMENT_SHADER)
    Shader_programm = OpenGL.GL.shaders.compileProgram(vertex_shader, fragment_shader)

# ==========================================================
# LOOP DE RENDERIZAÇÃO PRINCIPAL
# ==========================================================

def render_loop():
    # ======================================================
    # MONTAGEM DO CENÁRIO (RPG BATTLE)
    # ======================================================
    
    escala_chibi = pyrr.matrix44.create_from_scale(Vector3([0.4, 0.4, 0.4]))

    # Posições da "Party" no grid de combate
    translacao_p1 = pyrr.matrix44.create_from_translation(Vector3([-3.0, 0.0, 0.0]))
    translacao_p2 = pyrr.matrix44.create_from_translation(Vector3([0.0, 0.0, 2.0]))
    translacao_p3 = pyrr.matrix44.create_from_translation(Vector3([3.0, 0.0, 0.0]))

    model_chibi_1 = pyrr.matrix44.multiply(translacao_p1, escala_chibi)
    model_chibi_2 = pyrr.matrix44.multiply(translacao_p2, escala_chibi)
    model_chibi_3 = pyrr.matrix44.multiply(translacao_p3, escala_chibi)

    # Boss: O Gato Gigante
    escala_cat = pyrr.matrix44.create_from_scale(Vector3([0.25, 0.25, 0.25]))
    rotacao_cat_x = pyrr.matrix44.create_from_x_rotation(np.radians(90))
    translacao_cat = pyrr.matrix44.create_from_translation(Vector3([0.0, -2.0, -10.0]))

    model_cat = pyrr.matrix44.multiply(rotacao_cat_x, escala_cat)
    model_cat = pyrr.matrix44.multiply(translacao_cat, model_cat)

    last_time = glfw.get_time()
    base_speed = 10.0

    while not glfw.window_should_close(Window):
        current_time = glfw.get_time()
        delta = current_time - last_time
        last_time = current_time
        vel = base_speed * delta

        # Controles de Câmera (Andar pelo grid)
        if glfw.get_key(Window, glfw.KEY_W) == glfw.PRESS:
            cam.process_keyboard("FORWARD", vel)
        if glfw.get_key(Window, glfw.KEY_S) == glfw.PRESS:
            cam.process_keyboard("BACKWARD", vel)
        if glfw.get_key(Window, glfw.KEY_A) == glfw.PRESS:
            cam.process_keyboard("LEFT", vel)
        if glfw.get_key(Window, glfw.KEY_D) == glfw.PRESS:
            cam.process_keyboard("RIGHT", vel)

        glClearColor(0.05, 0.1, 0.1, 1.0) # Fundo levemente escurecido para atmosfera de masmorra
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        glUseProgram(Shader_programm)

        view = cam.get_view_matrix()
        projection = pyrr.matrix44.create_perspective_projection_matrix(45.0, WIDTH / HEIGHT, 0.1, 100.0)

        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "view"), 1, GL_FALSE, view)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "projection"), 1, GL_FALSE, projection)

        # ==================================================
        # RENDERIZAÇÃO DA PARTY (CHIBIS)
        # ==================================================
        glBindVertexArray(vao_chibi)
        glBindTexture(GL_TEXTURE_2D, textura_chibi)

        # Chibi 1 (Flanco Esquerdo)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "model"), 1, GL_FALSE, model_chibi_1)
        glDrawArrays(GL_TRIANGLES, 0, num_vertices_chibi)

        # Chibi 2 (Vanguarda/Tanque)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "model"), 1, GL_FALSE, model_chibi_2)
        glDrawArrays(GL_TRIANGLES, 0, num_vertices_chibi)

        # Chibi 3 (Flanco Direito)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "model"), 1, GL_FALSE, model_chibi_3)
        glDrawArrays(GL_TRIANGLES, 0, num_vertices_chibi)

        # ==================================================
        # RENDERIZAÇÃO DO BOSS (GATO)
        # ==================================================
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "model"), 1, GL_FALSE, model_cat)
        glBindVertexArray(vao_cat)
        glBindTexture(GL_TEXTURE_2D, textura_cat)
        glDrawArrays(GL_TRIANGLES, 0, num_vertices_cat)

        glfw.swap_buffers(Window)
        glfw.poll_events()

    glfw.terminate()

def main():
    global vao_chibi, num_vertices_chibi, textura_chibi
    global vao_cat, num_vertices_cat, textura_cat

    inicializa_opengl()

    vao_chibi, num_vertices_chibi, textura_chibi = carregar_objeto(ARQUIVO_OBJ_CHIBI, ARQUIVO_TEX_CHIBI)
    vao_cat, num_vertices_cat, textura_cat = carregar_objeto(ARQUIVO_OBJ_CAT, ARQUIVO_TEX_CAT)

    inicializa_shaders()
    render_loop()

if __name__ == "__main__":
    main()