/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_2;

import Conexao.Conexao;

/**
 *
 * @author laboratorio
 */
public class Main {
    
    public static void main(String[] args) {
        
        Conexao c = new Conexao();
        c.getConexao();
        
    }
    
}
