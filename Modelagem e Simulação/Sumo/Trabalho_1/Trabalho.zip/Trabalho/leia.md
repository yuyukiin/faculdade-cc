# Passo a Passo

## 1. Baixar SUMO
- Abra o CMD.
- Execute o seguinte comando:
  ```bash
  PS C:\Program Files (x86)\Eclipse\Sumo\tools> python .\osmWebWizard.py

## 2. Abrir site
- Adicione carros
- Clique para gerar o mapa

## 3. No SUMO
- Ache um local com sinaleira
- Alterar tempo da sinaleira
- Clique para gerar o mapa


