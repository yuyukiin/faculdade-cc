package DAO;

import Conexao.Conexao;
import mercado.Categoria;
import mercado.Produto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {

    private Conexao conexao;
    private Connection conn;

    public ProdutoDAO() {
        this.conexao = new Conexao();
        this.conn = conexao.getConexao();
    }

    // Método para adicionar um novo produto
    public boolean adicionarProduto(Produto produto) {
        String sql = "INSERT INTO Produtos (nome, preco, quantidade, categoria_id) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, produto.getNome());
            stmt.setDouble(2, produto.getPreco());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setInt(4, produto.getCategoria().getId());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar produto: " + e.getMessage());
            return false;
        }
    }

    // Método para listar todos os produtos
    public List<Produto> listarProdutos() {
        String sql = "SELECT p.id, p.nome, p.preco, p.quantidade, c.id AS categoria_id, c.nome AS categoria_nome FROM Produtos p "
                   + "JOIN Categorias c ON p.categoria_id = c.id";
        List<Produto> produtos = new ArrayList<>();
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Categoria categoria = new Categoria();
                categoria.setId(rs.getInt("categoria_id"));
                categoria.setNome(rs.getString("categoria_nome"));

                Produto produto = new Produto();
                produto.setId(rs.getInt("id"));
                produto.setNome(rs.getString("nome"));
                produto.setPreco(rs.getDouble("preco"));
                produto.setQuantidade(rs.getInt("quantidade"));
                produto.setCategoria(categoria);

                produtos.add(produto);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar produtos: " + e.getMessage());
        }
        return produtos;
    }

    // Método para atualizar um produto existente
    public boolean atualizarProduto(Produto produto) {
        String sql = "UPDATE Produtos SET nome = ?, preco = ?, quantidade = ?, categoria_id = ? WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, produto.getNome());
            stmt.setDouble(2, produto.getPreco());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setInt(4, produto.getCategoria().getId());
            stmt.setInt(5, produto.getId());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar produto: " + e.getMessage());
            return false;
        }
    }

    // Método para deletar um produto
    public boolean deletarProduto(int id) {
        String sql = "DELETE FROM Produtos WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar produto: " + e.getMessage());
            return false;
        }
    }
    
    public List<Produto> buscarProdutos(String nome, Categoria categoria) {
        List<Produto> listaProdutos = new ArrayList<>();
        String sql = "SELECT p.*, c.nome AS categoria_nome FROM Produtos p " +
                     "JOIN Categorias c ON p.categoria_id = c.id " +
                     "WHERE p.nome LIKE ?";

        if (categoria != null) {
            sql += " AND c.id = ?";
        }

        try (
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, "%" + nome + "%");
            if (categoria != null) {
                stmt.setInt(2, categoria.getId());
            }

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt("id"));
                produto.setNome(rs.getString("nome"));
                produto.setPreco(rs.getDouble("preco"));
                produto.setQuantidade(rs.getInt("quantidade"));

                Categoria cat = new Categoria();
                cat.setId(rs.getInt("categoria_id"));
                cat.setNome(rs.getString("categoria_nome"));
                produto.setCategoria(cat);

                listaProdutos.add(produto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaProdutos;
    }

    
}
