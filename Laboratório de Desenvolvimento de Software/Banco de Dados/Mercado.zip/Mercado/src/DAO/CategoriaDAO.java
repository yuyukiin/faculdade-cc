/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import java.sql.Connection;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import mercado.Categoria;

/**
 *
 * @author Pedr0xh
 */
public class CategoriaDAO {
    
    private Conexao conexao;
    private Connection conn;
    
    public CategoriaDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public List<Categoria> getCategoria(){
        
        String sql = "SELECT * FROM Categorias";
    
    try {
            
            //Prepara a consulta, 
            //Primeiro param - String da consulta em sql
            //Segundo param - Result set insensitive, pode ir tanto para frente como para tras, não reflete as mudançãs no banco
            //Terceiro param - Pode modificar as alterações direto do ResultSet
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            //Executa a consulta
            ResultSet rs = stmt.executeQuery();
            
            //Cria uma lista para armazenar as Pessoas 
            List<Categoria> listaCategorias = new ArrayList();
            
            //Loop que percorre todas as linhas da query executada 
            while (rs.next()) {
                Categoria c = new Categoria();
                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));
                listaCategorias.add(c);
            }
            
            return listaCategorias;
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar todas as pesoas: "+ex.getMessage());
            return null;
        }
    
}
    
}
