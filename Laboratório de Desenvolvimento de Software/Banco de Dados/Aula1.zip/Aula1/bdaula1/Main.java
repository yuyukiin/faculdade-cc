/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bdaula1;

/**
 *
 * @author laboratorio
 */

import Conexao.Conexao;
import DAO.PessoaDAO;


public class Main {
    public static void main(String[] args){
        Conexao c = new Conexao();
        c.getConexao();
        
        PessoaDAO PDAO = new PessoaDAO();
        Pessoa p = new Pessoa();
        p.setNome("Ricardo");
        p.setSexo("M");
        p.setIdioma("Portugûes");
        
        PDAO.inserir(p);
        
    }
}
