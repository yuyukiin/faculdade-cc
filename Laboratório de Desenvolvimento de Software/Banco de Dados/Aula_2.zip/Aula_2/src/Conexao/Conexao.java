
package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author laboratorio
 */
public class Conexao {
    
    public Connection getConexao(){
        
        try{
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/bdaula01?userTimeZone=true"
                    +"&serverTimeZone=UTC","root","laboratorio"
            );
            System.out.println("Conexao feita");
            return conn;
        }
        catch(Exception e){
            System.out.println("Conexao nao feita");
            return null;
        }
        
    }
    
}

