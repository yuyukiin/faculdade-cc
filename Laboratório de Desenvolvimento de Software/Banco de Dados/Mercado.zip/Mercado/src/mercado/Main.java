/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mercado;
import Conexao.Conexao;
import DAO.CategoriaDAO;
import DAO.ProdutoDAO;
import java.util.List;

/**
 *
 * @author Pedr0xh
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Conexao c = new Conexao();
        c.getConexao();
        
        CategoriaDAO cDAO = new CategoriaDAO();
        List<Categoria> lista = cDAO.getCategoria();
        
        System.out.println(lista);
        
        ProdutoDAO pDAO = new ProdutoDAO();
        List<Produto> listaP = pDAO.listarProdutos();
        
        System.out.println(listaP);
        
        
    }
    
}
