/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

/**
 *
 * @author laboratorio
 */
public class LabirintoAvaliacao {

    
    public static void main(String[] args) {
        
        java.awt.EventQueue.invokeLater(() -> {
            new Interface().setVisible(true);
        });
        
    }
    
}
