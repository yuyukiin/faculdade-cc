package MetodosBusca;

import java.util.PriorityQueue;
import java.util.ArrayList;
import javax.swing.JOptionPane;

class Celula implements Comparable<Celula> {
    int x, y;
    int heuristica;

    public Celula(int x, int y, int heuristica) {
        this.x = x;
        this.y = y;
        this.heuristica = heuristica;
    }

    @Override
    public int compareTo(Celula o) {
        return Integer.compare(this.heuristica, o.heuristica);
    }
}

public class Guloso {
    
    private static final int[] dx = {0, 0, 1, -1};   
    private static final int[] dy = {1, -1, 0, 0};   

    public static boolean guloso(int[][] labirinto, int startX, int startY, int goalX, int goalY) {
        int n = labirinto.length;
        PriorityQueue<Celula> fronteira = new PriorityQueue<>();
        boolean[][] visitado = new boolean[n][n];
        ArrayList<String> caminho = new ArrayList<>();
        
        fronteira.add(new Celula(startX, startY, heuristica(startX, startY, goalX, goalY)));

        while (!fronteira.isEmpty()) {
            Celula atual = fronteira.poll();
            int x = atual.x;
            int y = atual.y;

            if (visitado[x][y]) continue; // Evita reprocessar a mesma célula
            
            visitado[x][y] = true;
            caminho.add("Movendo para (" + x + ", " + y + ")");

            if (x == goalX && y == goalY) {
                caminho.add("Saída encontrada!");
                exibirCaminho(caminho);
                return true;
            }

            for (int i = 0; i < 4; i++) {
                int novoX = x + dx[i];
                int novoY = y + dy[i];

                if (ehValido(novoX, novoY, n, labirinto, visitado)) {
                    fronteira.add(new Celula(novoX, novoY, heuristica(novoX, novoY, goalX, goalY)));
                }
            }
        }

        caminho.add("Nenhuma saída encontrada.");
        exibirCaminho(caminho);
        return false;
    }

    private static int heuristica(int x, int y, int goalX, int goalY) {
        return Math.abs(x - goalX) + Math.abs(y - goalY);
    }

    private static boolean ehValido(int x, int y, int n, int[][] labirinto, boolean[][] visitado) {
        return (x >= 0 && x < n && y >= 0 && y < n && labirinto[x][y] != 1 && !visitado[x][y]);
    }

    private static void exibirCaminho(ArrayList<String> caminho) {
        StringBuilder sb = new StringBuilder();
        for (String passo : caminho) {
            sb.append(passo).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
}
